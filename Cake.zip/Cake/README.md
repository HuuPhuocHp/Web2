# CakeWebSite
🍰 CakeWebSite CakeWebSite is an online cake sales website designed to provide customers with an easy and engaging shopping experience. This project allows users to browse through a wide variety of cakes, from birthday cakes, wedding cakes to other handmade pastries.
