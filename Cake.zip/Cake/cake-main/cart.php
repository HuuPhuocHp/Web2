<?php
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");
session_start();

// Kiểm tra trạng thái đăng nhập
if (!isset($_SESSION['user'])) {
    $_SESSION['error'] = "";
    header('location: /cake-main/login.php'); // Chuyển hướng đến trang đăng nhập
    exit();
}

class Cart {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function addToCart($id, $quantity) {
        $query = "SELECT * FROM Products WHERE ProductId = '$id'";
        $data = mysqli_query($this->conn, $query);
    
        if ($data && $product = mysqli_fetch_assoc($data)) {
            $available_quantity = $product['Avaiable_quantity'];
    
            if (isset($_SESSION['cart'][$id])) {
                if ($_SESSION['cart'][$id]['quantity'] + $quantity <= $available_quantity) {
                    $_SESSION['cart'][$id]['quantity'] += $quantity;
                    $_SESSION['message'] = "Thêm sản phẩm '{$product['Name']}' vào giỏ hàng thành công!";
                } else {
                    $_SESSION['error'] = "Sản phẩm '{$product['Name']}' không đủ số lượng. Chỉ còn lại {$available_quantity} sản phẩm.";
                }
            } else {
                if ($quantity <= $available_quantity) {
                    $_SESSION['cart'][$id] = [
                        'id' => $product['ProductId'],
                        'name' => $product['Name'],
                        'quantity' => $quantity,
                        'sellprice' => $product['SellPrice'],
                        'image' => $product['Image'],
                    ];
                    $_SESSION['message'] = "Thêm sản phẩm '{$product['Name']}' vào giỏ hàng thành công!";
                } else {
                    $_SESSION['error'] = "Sản phẩm '{$product['Name']}' không đủ số lượng. Chỉ còn lại {$available_quantity} sản phẩm.";
                }
            }
        } else {
            $_SESSION['error'] = "Sản phẩm không tồn tại.";
        }

        // Cập nhật tổng tiền giỏ hàng
        $this->updateCartTotal();
    }

    public function updateCartQuantity($id, $quantity) {
        $query = "SELECT Avaiable_quantity, Name FROM Products WHERE ProductId = '$id'";
        $data = mysqli_query($this->conn, $query);
    
        if ($data && $product = mysqli_fetch_assoc($data)) {
            $available_quantity = $product['Avaiable_quantity'];
            
            if ($quantity <= $available_quantity) {
                $_SESSION['cart'][$id]['quantity'] = $quantity;
                $_SESSION['message'] = "Cập nhật số lượng sản phẩm '{$product['Name']}' thành công!";
            } else {
                $_SESSION['error'] = "Sản phẩm '{$product['Name']}' không đủ số lượng. Chỉ còn lại {$available_quantity} sản phẩm.";
            }
        } else {
            $_SESSION['error'] = "Sản phẩm không tồn tại.";
        }

        // Cập nhật tổng tiền giỏ hàng
        $this->updateCartTotal();
    }

    public function deleteFromCart($id) {
        $query = "SELECT Name FROM Products WHERE ProductId = '$id'";
        $data = mysqli_query($this->conn, $query);
    
        if ($data && mysqli_num_rows($data) > 0) {
            if (isset($_SESSION['cart'][$id])) {
                $product_name = $_SESSION['cart'][$id]['name'];
                unset($_SESSION['cart'][$id]);
                $_SESSION['message'] = "Xóa sản phẩm '{$product_name}' khỏi giỏ hàng thành công!";
            }
        } else {
            $_SESSION['error'] = "Sản phẩm không tồn tại.";
        }

        // Cập nhật tổng tiền giỏ hàng
        $this->updateCartTotal();
    }

    private function updateCartTotal() {
        $total_price = 0;
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $total_price += $item['sellprice'] * $item['quantity'];
            }
        }
        $_SESSION['total_price'] = $total_price;
    }
}

// Xử lý logic giỏ hàng
if (isset($_GET['id'])) {
    $id = $_GET['id'];
}

$action = (isset($_GET['action'])) ? $_GET['action'] : 'add';
$quantity = (isset($_GET['quantity'])) ? (int)$_GET['quantity'] : 1;

if ($quantity <= 0) {
    $quantity = 1;
}

// Khởi tạo đối tượng Cart
$cart = new Cart($conn);

switch ($action) {
    case 'add':
        $cart->addToCart($id, $quantity);
        break;
    case 'update':
        $cart->updateCartQuantity($id, $quantity);
        break;
    case 'delete':
        $cart->deleteFromCart($id);
        break;
    default:
        $_SESSION['error'] = "Hành động không hợp lệ.";
        break;
}

header('location: view_cart.php');
exit();
?>
