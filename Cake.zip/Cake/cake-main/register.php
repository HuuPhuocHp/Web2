<?php
    include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/auth_header.php");
    include($_SERVER['DOCUMENT_ROOT'] . "/classes/user_register.php");
?>
<?php
$ad = new user_register();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $insertUser = $ad->insert_user($_POST);
}
?>
<section class="hero">
    <style>
        .site-btn {
            display: inline-block;
            width: 100%; /* Đảm bảo nút chiếm toàn bộ chiều rộng container */
            max-width: 600px; /* Đặt chiều rộng tối đa là 600px */
            padding: 14px 30px; /* Padding trên-dưới: 14px, trái-phải: 30px */
            background-color: black; /* Nền màu đen */
            color: white; /* Màu chữ mặc định */
            text-align: center;
            border: none;
            border-radius: 5px; /* Bo góc */
            font-size: 16px; /* Kích thước chữ */
            text-decoration: none; /* Xóa gạch chân */
            cursor: pointer; /* Con trỏ chuột */
            transition: color 0.3s ease, background-color 0.3s ease; /* Hiệu ứng chuyển đổi */
        }

        .site-btn:hover {
            color: blue; /* Chữ chuyển thành màu xanh dương khi hover */
        }

        .site-btn.mt-4 {
            margin-top: 16px; /* Khoảng cách trên */
        }
    </style>
    <div class="hero__item set-bg" data-setbg="img/hero/hero-1.jpg">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6">
                    <div class="class__sidebar">
                        <h5 style="font-family: Callephane; margin-left: 200px;">
                            <img src="img/logo_2.png" alt="">Register
                        </h5>
                        <form action="register.php" method="post">
                            <input type="text" placeholder="Enter your name" name="Fullname">
                            <input type="text" placeholder="Enter your email" name="Email">
                            <input type="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" name="Password">
                            <button type="submit" class="site-btn">register</button>
                            <a href="login.php" class="site-btn mt-4">login</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->

<?php
    include($_SERVER["DOCUMENT_ROOT"] . '/cake-main/inc/footer.php');
?>