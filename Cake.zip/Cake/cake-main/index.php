<?php
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/header.php");
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");

$query = "SELECT *FROM Products where status = 1 and is_accept = 1 order by CountView desc";
$Products = mysqli_query($conn, $query);

?>
<!-- Owl Carousel CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Owl Carousel JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

<!-- Hero Section Begin -->
<section class="hero">
    <div class="hero__slider owl-carousel">
        <div class="hero__item set-bg" data-setbg="img/hero/hero-1.jpg">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-8">
                        <div class="hero__text">
                            <h2>Chúng tôi làm cuộc sống của bạn ngọt ngào hơn từng miếng bánh!</h2>
                            <a href="#" class="primary-btn">Our cakes</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero__item set-bg" data-setbg="img/hero/hero-1.jpg">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="col-lg-8">
                        <div class="hero__text">
                            <h2>Chúng tôi làm cuộc sống của bạn ngọt ngào hơn từng miếng bánh!</h2>
                            <a href="#" class="primary-btn">Bánh của chúng tôi</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<!-- Hero Section End -->

<!-- About Section Begin -->
<section class="about spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="about__text">
                    <div class="section-title">
                        <span>Về Cửa Hàng Bánh</span>
                        <h2>Bánh và các sản phẩm nướng từ nhà Queens!</h2>
                    </div>
                    <p>"Cake Shop" là một thương hiệu Jordan, bắt đầu là một doanh nghiệp gia đình nhỏ. Các chủ sở hữu là
                        Tiến sĩ Iyad Sultan và Tiến sĩ Sereen Sharabati, được hỗ trợ bởi đội ngũ 80 nhân viên.
                    </p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="about__bar">
                    <div class="about__bar__item">
                        <p>Thiết kế bánh</p>
                        <div id="bar1" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="95"></span>
                        </div>
                    </div>
                    <div class="about__bar__item">
                        <p>Lớp học làm bánh</p>
                        <div id="bar2" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="80"></span>
                        </div>
                    </div>
                    <div class="about__bar__item">
                        <p>Công thức bánh</p>
                        <div id="bar3" class="barfiller">
                            <div class="tipWrap"><span class="tip"></span></div>
                            <span class="fill" data-percentage="90"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Section End -->

<!-- Categories Section Begin -->
<!-- Categories Section End -->
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="section-title">
                <span>Sản Phẩm Nổi Bật</span>
            </div>
        </div>
    </div>
</div>
<!-- Product Section Begin -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="product__slider owl-carousel">
                    <?php foreach ($Products as $key => $value) : ?>
                        <div class="product__item">
                            <div class="product__item__pic set-bg">
                                <a href="product_detail.php?id=<?php echo $value['ProductId']; ?>">
                                    <img src="../admin/uploads/<?php echo $value['Image']; ?>" alt="Chi tiết sản phẩm">
                                </a>
                            </div>
                            <div class="product__item__text">
                                <h6>
                                    <a href="product_detail.php?id=<?php echo $value['ProductId']; ?>">
                                        <?php echo $value['Name']; ?>
                                    </a>
                                    <?php if ($value['CountView'] > 20): ?>
                                        <span style="color: red;">
                                            <i class="fas fa-fire"></i> Hot
                                        </span>
                                    <?php endif; ?>
                                </h6>
                                <h5>Giá: <?php echo $value['SellPrice'] . ' USD'; ?></h5>
                                <h6>
                                    <i class="fas fa-eye"></i> <?php echo $value['CountView']; ?>
                                </h6>
                                <div>
                                    <?php if ($value['Avaiable_quantity'] > 0): ?>
                                        <button class="btn primary-btn mt-4">
                                            <a style="color: white" href="cart.php?id=<?php echo $value['ProductId']; ?>">Thêm giỏ hàng</a>
                                        </button>
                                    <?php else: ?>
                                        <span style="color: red;">Hết hàng</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    $(document).ready(function(){
        $(".product__slider").owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            dots: false,
            items: 4, // Hiển thị 4 sản phẩm cùng lúc
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 4
                }
            }
        });
    });
</script>
<!-- Team Section End -->

<!-- Testimonial Section Begin -->
<section class="testimonial spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="section-title">
                    <span>Đánh Giá</span>
                    <h2>Ý kiến khách hàng</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="testimonial__slider owl-carousel">
                <div class="col-lg-6">
                    <div class="testimonial__item">
                        <div class="testimonial__author">
                            <div class="testimonial__author__pic">
                                <img src="img/testimonial/ta-1.jpg" alt="">
                            </div>
                            <div class="testimonial__author__text">
                                <h5>Gia Khánh</h5>
                                <span>Quảng Bình</span>
                            </div>
                        </div>
                        <div class="rating">
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star-half_alt"></span>
                        </div>
                        <p>Sản phẩm thật sự rất tuyệt vời! Chất lượng vượt trội, thiết kế tinh tế và sử dụng rất dễ dàng. Tôi đặc biệt thích tính năng bảo mật, giúp tôi yên tâm hơn khi sử dụng. Dịch vụ giao hàng cũng rất nhanh chóng. Tôi rất hài lòng và sẽ giới thiệu cho bạn bè.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testimonial__item">
                        <div class="testimonial__author">
                            <div class="testimonial__author__pic">
                                <img src="img/testimonial/ta-2.jpg" alt="">
                            </div>
                            <div class="testimonial__author__text">
                                <h5>Gia Khánh</h5>
                                <span>Quảng Bình</span>
                            </div>
                        </div>
                        <div class="rating">
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star-half_alt"></span>
                        </div>
                        <p>Tôi đã sử dụng sản phẩm này được vài tuần và nhìn chung là khá hài lòng. Chất lượng ổn, tuy nhiên tôi mong muốn sản phẩm có thêm vài tính năng nâng cao để tiện lợi hơn. Dịch vụ khách hàng rất chu đáo, nhưng tôi hy vọng giá cả có thể hợp lý hơn một chút.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="testimonial__item">
                        <div class="testimonial__author">
                            <div class="testimonial__author__pic">
                                <img src="img/testimonial/ta-1.jpg" alt="">
                            </div>
                            <div class="testimonial__author__text">
                                <h5>Hoàng Duy</h5>
                                <span>Cali</span>
                            </div>
                        </div>
                        <div class="rating">
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star"></span>
                            <span class="icon_star-half_alt"></span>
                        </div>
                        <p>Sản phẩm thực sự đáp ứng đúng kỳ vọng của tôi. Chất lượng tốt, dễ sử dụng và hỗ trợ kỹ thuật rất nhanh chóng. Tuy nhiên, nếu có thêm một số tính năng tích hợp với các thiết bị khác sẽ làm sản phẩm hoàn hảo hơn. Dù vậy, tôi vẫn rất hài lòng và sẽ tiếp tục sử dụng.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Section End -->

<!-- Instagram Section Begin -->
<section class="instagram spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 p-0">
                <div class="instagram__text">
                    <div class="section-title">
                        <span>Theo dõi chúng tôi trên Instagram</span>
                        <h2>Những khoảnh khắc ngọt ngào nhất!</h2>
                    </div>
                    <h5><i class="fa fa-instagram"></i> @sweetcake</h5>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic">
                            <img src="img/instagram/instagram-1.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic middle__pic">
                            <img src="img/instagram/instagram-2.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic">
                            <img src="img/instagram/instagram-3.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic">
                            <img src="img/instagram/instagram-4.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic middle__pic">
                            <img src="img/instagram/instagram-5.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-6">
                        <div class="instagram__pic">
                            <img src="img/instagram/instagram-3.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Instagram Section End -->

<!-- Map Begin -->
<div class="map">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-7">
                <div class="map__inner">
                    <h6>Cake</h6>
                    <ul>
                        <li>273 An Dương Vương, Quận 5, TP HCM</li>
                        <li>Sweetcake@support.com</li>
                        <li>0901641800</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="map__iframe">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d10784.188505644011!2d19.053119335158936!3d47.48899529453826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1543907528304" height="300" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>
</div>
<!-- Map End -->
<?php
include($_SERVER["DOCUMENT_ROOT"] . '/cake-main/inc/footer.php');
?>