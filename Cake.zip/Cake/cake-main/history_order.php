<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);

// Kết nối cơ sở dữ liệu và thêm các file cần thiết
include($_SERVER['DOCUMENT_ROOT'] . "/cake-main/inc/header.php");
include($_SERVER['DOCUMENT_ROOT'] . "/database/connect.php");
include($_SERVER['DOCUMENT_ROOT'] . "/classes/cart.php");

// Lớp OrderHistory xử lý lịch sử đơn hàng
class OrderHistory {
    private $conn;
    private $userId;

    public function __construct($conn, $userId) {
        $this->conn = $conn;
        $this->userId = $userId;
    }

    // Phương thức lấy dữ liệu đơn hàng
    public function getOrderData() {
        $query = "SELECT o.order_date, o.status, a.Quantity, p.Name, a.Price, p.Image FROM `oders` o
                  JOIN orderdetails a ON o.OderId = a.Order_Detail_Id
                  JOIN products p ON p.ProductId = a.ProductId
                  WHERE o.CustomerId = '$this->userId'";

        return mysqli_query($this->conn, $query);
    }

    // Phương thức lấy trạng thái đơn hàng
    public function getOrderStatus($status) {
        switch ($status) {
            case 0: return 'Chưa xử lý';
            case 1: return 'Đã hủy';
            case 2: return 'Đã xử lý';
            case 3: return 'Đã giao hàng';
            default: return 'Không xác định';
        }
    }

    // Phương thức tính tổng tiền
    public function calculateTotalPrice($orderData) {
        $total_price = 0;
        foreach ($orderData as $item) {
            $total_price += $item['Price'] * $item['Quantity'];
        }
        return $total_price;
    }
}

// Kiểm tra người dùng đã đăng nhập hay chưa
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
    $id_user = $user['CustomerId'];

    // Tạo đối tượng OrderHistory
    $orderHistory = new OrderHistory($conn, $id_user);
    $data = $orderHistory->getOrderData();
    $total_price = $orderHistory->calculateTotalPrice($data);
} else {
    $user = [];
}
?>

<!-- HTML phần breadcrumb -->
<div class="breadcrumb-option">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__text">
                    <h2>Lịch Sử Mua Hàng</h2>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="breadcrumb__links">
                    <a href="./index.php">Trang chủ</a>
                    <a href="./list_product.php">Cửa hàng</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- HTML phần Shop Section -->
<section class="shop spad">
    <?php if (isset($_SESSION['user'])) { ?>
        <div class="container">
            <div class="row">
                <div class="table-responsive text-nowrap">
                    <table class="table" style="text-align: center">
                        <thead>
                            <tr>
                                <th>STT</th>
                                <th>Tên sản phẩm</th>
                                <th>Hình ảnh</th>
                                <th>Ngày đặt hàng</th>
                                <th>Số lượng</th>
                                <th>Đơn giá</th>
                                <th>Thành tiền</th>
                                <th>Trạng thái đơn hàng</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php
                            $stt = 1;
                            foreach ($data as $value) {
                            ?>
                                <tr>
                                    <td><?php echo $stt++ ?></td>
                                    <td><?php echo $value['Name'] ?></td>
                                    <td>
                                        <img src="../admin/uploads/<?php echo $value['Image'] ?>" alt="" width="120">
                                    </td>
                                    <td><?php echo $value['order_date'] ?></td>
                                    <td><?php echo $value['Quantity'] ?></td>
                                    <td><?php echo $value['Price'] ?> USD</td>
                                    <td><?php echo $value['Price'] * $value['Quantity'] ?> USD</td>
                                    <td>
                                        <?php echo $orderHistory->getOrderStatus($value['status']); ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td>Tổng tiền</td>
                                <td colspan="6"><?php echo $total_price ?> USD</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php } else { ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <strong>Vui lòng đăng nhập để xem lịch sử mua hàng</strong>
            <a href="login.php">Đăng nhập</a>
        </div>
    <?php } ?>
</section>

<!-- Footer -->
<?php
include($_SERVER["DOCUMENT_ROOT"] . '/cake-main/inc/footer.php');
?>
